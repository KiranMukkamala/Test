npm i
while sleep 3; do sh build.sh; done
