function getStrongPassword(isAlphaNumericOnly = false) {
  function _getRandomInt(min, max) {
    min = Math.ceil(min);
    max = Math.floor(max);
    return Math.floor(Math.random() * (max - min + 1)) + min;
  }

  function _getUpperCase() {
    return `
      ABCDEFGHJKMNPQRSTUVWXYZ
    `.replace(/[ \n\t]/g, '');
  }

  function _getLowerCase() {
    return _getUpperCase().toLowerCase();
  }

  function _getSpecialChars() {
    return `
      -=
      @#$%^&*()+
      [],./
      {}|<>?
    `.replace(/[ \n\t]/g, '');
  }

  function _getNumbers() {
    return `
      234567890
    `.replace(/[ \n\t]/g, '');
  }

  function _getRandomOption(choices) {
    return choices[_getRandomInt(0, choices.length)] || '';
  }

  function _getPassword(minLength = 20) {
    let password = '';
    let choices = [..._getNumbers(), ..._getLowerCase()];

    if (isAlphaNumericOnly === false) {
      password += _getRandomOption(_getUpperCase());
      password += _getRandomOption(_getLowerCase());
      password += _getRandomOption(_getSpecialChars());
      password += _getRandomOption(_getNumbers());

      choices = [...choices, ..._getUpperCase(), ..._getSpecialChars()];
    } else {
      password += _getRandomOption(_getLowerCase());
    }

    choices = [...new Set(choices)];

    while (password.length < minLength) {
      try {
        password += _getRandomOption(choices);
      } catch (err) {}
    }
    return password;
  }

  // dispatch event to copy text to clipboard
  const eventAppCopyTextToClipboard = new Event('AppCopyTextToClipboard');
  eventAppCopyTextToClipboard.text = _getPassword();
  document.dispatchEvent(eventAppCopyTextToClipboard);
}

// hook up custom event
document.addEventListener('NavBeforeLoad', async (e) => {
  const { renderSchema } = e;

  if (!renderSchema) {
    return;
  }

  const SITE_SCHEMA = `
  ! Kiran's Favorites
  @ 🧑

  #general
  BOSCH HOME | https://inside.bosch.com/irj/portal
  WFM@BOSCH | https://si0bos301.de.bosch.com:8447/SES/sso?configfile=ESSConfiguration_M05.xml&redirected=true
  IDM | https://rb-im.bosch.com/BOAWeb/selfservice
  IT Service Portal | https://rb-servicecatalog.apps.intranet.bosch.com/RequestCenter/website/Grunt/application/home.html?
  iGPR Monthly Time | https://rb-wam.bosch.com/mcr-apigateway-pro-mt/igpm_mcr_mytime_fe/booking
  Daily Time Management | https://si0bos301.de.bosch.com:8447/SES/sso?configfile=ESSConfiguration_M05.xml&redirected=true
  Lunch Menu | http://www.intranet.bosch.com/z2s/WVP-Fe/Tagesangebot/Tagesangebot_Fe101.pdf
  Learning Home | https://bosch.plateau.com/learning/user/personal/landOnPortalHome.do?OWASP_CSRFTOKEN=7U3D-TH7N-IJA4-X9J9-UTEA-DZOQ-Q1Z0-IIDK&fromSF=Y&fromDeepLink=true&pageID=
  UGA | https://rb-uga.de.bosch.com/uga/index.php?page=settings&language=en
  URS HOME | https://rb-urs-n1.bosch.com/URSXFrontEnd/Sites/Home.cshtml?rid=QM2cDOxEDOzczN

  #One Parking
  OneParking Links | https://inside-docupedia.bosch.com/confluence/display/CCD/OneParking+Links
  OneParking Platform Home - OneParking Platform Wiki - Docupedia | https://inside-docupedia.bosch.com/confluence/display/PARKING/OneParking+Platform+Home
  OneParking Platform System Model - OneParking Platform Wiki - Docupedia | https://inside-docupedia.bosch.com/confluence/display/PARKING/OneParking+Platform+System+Model
  MBSE Methodology - BBM Model-Based Systems Engineering - Docupedia | https://inside-docupedia.bosch.com/confluence/display/BBMMBSE/MBSE+Methodology
  Training MBSE - BBM Model-Based Systems Engineering - Docupedia | https://inside-docupedia.bosch.com/confluence/display/BBMMBSE/Training+MBSE
  WebEA - login | https://xc-ea.de.bosch.com/WebEA/login.php
  OneParking - tracker08 | https://rb-tracker.bosch.com/tracker08/projects/OPGI/summary
  Internal Block Diagram (IBD) - Bosch Tube | https://tube.video.bosch.com/media/Internal+Block+Diagram+%28IBD%29/0_b3o33xcg
  Bosch Tube-SySML | https://tube.video.bosch.com/tag?tagid=sysml
  MBSE@XC sync - XC Architecture - Docupedia | https://inside-docupedia.bosch.com/confluence/display/CCSA/2023-03-31+%7C+MBSE@XC+sync
  Q&A Topics - OneParking Platform Wiki - Docupedia | https://inside-docupedia.bosch.com/confluence/pages/viewpage.action?pageId=2979010993
  1P SYS - Architecture - Agile Board | https://rb-tracker.bosch.com/tracker08/secure/RapidBoard.jspa?rapidView=36005&quickFilter=158296

  #Process
  Method Park Stages | https://abt-prolib.de.bosch.com/stages/#/workspace/203/_vv/process/process/_HVPeQKUVlzi8jvTreF4jJw

  #Docupedia
  IT Service Portal | https://inside-docupedia.bosch.com/confluence/display/CI4U/IT+Service+Portal
  Dashboard | https://inside-docupedia.bosch.com/confluence/#all-updates
  
  #DOORs
  Citrix Workspace | https://virtualworkplace-internal-emea.bosch.com/Citrix/BoschCloudWorkplaceWeb/
  DOORs Docupedia| https://inside-docupedia.bosch.com/confluence/display/CCD/DOORS
  DOORs Access Request | https://rb-tracker.bosch.com/tracker12/servicedesk/customer/user/requests?status=open
  

  # personal
  synle | /
  email | mail.google.com/mail
  calendar | calendar.google.com/calendar
  enstroga | https://service.enstroga.de/login/magic-key/create
  
  
  # dev
  github repositories | github.com/synle?tab=repositories
  code spaces | github.com/codespaces

  # utils and misc
  ip location | whatismyipaddress.com
  bashrc | /bashrc/
  port forwarding | /app/port-forwarding.html
  fix link | /fix-tracking-link/
  nav bookmark generator ||| synle.github.io/nav-generator/index.html?newNav
  prettier playground | prettier.io/playground
  home router config | 192.168.1.1
  torrent | bit.ly/3pVvM2N
  strong password | javascript://getStrongPassword()
  alpha numeric password | javascript://getStrongPassword(true)


  # source code
  fav source | github.com/synle/fav
  nav generator source | github.com/synle/nav-generator
`
    .split('\n')
    .map((s) => s.trim())
    .join('\n');

  async function getHostMappingSchema() {
    let HOST_MAPPING_BLOCK_SCHEMA = '';

    const ETC_HOST_PATH_WIN32 = `c:\\Windows\\System32\\Drivers\\etc\\hosts`;
    const ETC_HOST_PATH_OSX = `/etc/hosts`;

    try {
      const HOSTNAMES_GROUPED_BY_ID = await fetch(
        `https://raw.githubusercontent.com/synle/bashrc/master/software/metadata/ip-address.config.hostnamesGroupedByID`,
      ).then((r) => r.text());
      const HOSTNAMES_MAPPINGS = await fetch(
        `https://raw.githubusercontent.com/synle/bashrc/master/software/metadata/ip-address.config.etcHostnamesMappings`,
      ).then((r) => r.text());

      HOST_MAPPING_BLOCK_SCHEMA = `
      # Host Mappings
      Host Mapping Ip Config|https://github.com/synle/bashrc/blob/master/software/metadata/ip-address.config
      >>> Host Files Location|tabHostDir >>> Host IPs|tabHostNamesGroupedByIp >>> /etc/hosts Mapping|tabHostMappings
      \`\`\`tabHostDir
      # Windows
      ${ETC_HOST_PATH_WIN32}

      # Linux
      ${ETC_HOST_PATH_OSX}
      \`\`\`

      \`\`\`tabHostNamesGroupedByIp
      ${HOSTNAMES_GROUPED_BY_ID}
      \`\`\`

      \`\`\`tabHostMappings
      # subl ${ETC_HOST_PATH_WIN32}
      # sudo vim ${ETC_HOST_PATH_OSX}
      # Sy Home Hosts
      ${HOSTNAMES_MAPPINGS}
      # END Sy Home Hosts
      \`\`\`
    `
        .split('\n')
        .map((s) => s.trim())
        .join('\n');
    } catch (err) {}

    return HOST_MAPPING_BLOCK_SCHEMA;
  }

  // construct and save the data to cache.
  renderSchema(`
    ${SITE_SCHEMA}
    ${await getHostMappingSchema()}
  `);
});
