# synle/fav

Sy's personal favorites

https://synle.github.io/fav/
