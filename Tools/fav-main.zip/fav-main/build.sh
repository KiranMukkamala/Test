sh format.sh

echo '>> Update ServiceWorker Version'
node updateServiceWorkerVersion.js 'sw-fav.js'
